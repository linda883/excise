from distutils.core import setup


setup(
    name='wrapperforlist',
    version='0.0.1',
    py_modules=['wrapperforlist'],
    author='linda',
    author_email='lindafanglizhi@163.com',
    url='',
    description='a simple printer of nested lists'
)
